<section id="partner" class="bg-light">
    <h1 class="text-center mb-5"><strong>Partenaires</strong></h1>

    <div class="container">
        <div class="row gy-4">
            <div class="col-lg-2 col-md-3 col-6">
                <img src="images/logo1.svg" alt="">
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <img src="images/logo2.svg" alt="">
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <img src="images/logo3.svg" alt="">
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <img src="images/logo4.svg" alt="">
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <img src="images/logo5.svg" alt="">
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <img src="images/logo1.svg" alt="">
            </div>
        </div>
    </div>
</section>
