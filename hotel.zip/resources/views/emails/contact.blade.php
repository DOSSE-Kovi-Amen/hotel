@section('content')
<h2>Nouveau message de contact</h2>

<p><strong>Nom:</strong> {{ $data['name'] }}</p>
<p><strong>Email:</strong> {{ $data['email'] }}</p>
<p><strong>Message:</strong></p>
<p>{{ $data['message'] }}</p>
@endsection