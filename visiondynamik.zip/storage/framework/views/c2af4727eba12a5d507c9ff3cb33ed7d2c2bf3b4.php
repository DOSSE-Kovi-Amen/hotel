<section id="contact">
    <h1 class="text-center mb-5"><strong>Nous contacter</strong></h1>

    <div class="container">
       <div class="row align-items-center">
         <div class="col-12 col-sm-6 col-lg-4">
            <img style="object-fit: cover; height:400px;width:100%" src="<?php echo e(asset('images/cntct.jpg')); ?>" alt="">
          </div>
          <div class="col-lg-6 offset-lg-1">
             <form>
                <div class="mb-3">
                  <small>Nom</small>
                  <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                </div>
                <div class="mb-3">
                   <small>Email</small>
                   <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                 </div>
                 <div class="mb-3">
                   <small>Message</small>
                   <textarea name="" id="" cols="30" rows="4" class="form-control"></textarea>
                 </div>
                <button type="submit" class="btn btn-primary">Envoyer</button>
              </form>
          </div>
       </div>
    </div>
 </section><?php /**PATH C:\Users\DOSSE KOVI AMEN\Desktop\Amen\visiondynamik\resources\views/includes/contact.blade.php ENDPATH**/ ?>