<?php $__env->startSection('content'); ?>
<div class="page-content browse container-fluid">
    <h2><?php echo e($activity->title); ?></h2>
    <div class="panel panel-bordered">
        <div class="panel-body">
            <div class="table-responsive">
                <table id="dataTable" class="table table-hover">
                    <thead>
                        <tr>
                            <th>Nom</th>
                            <th>Prénom</th>
                            <th>Naissance</th>
                            <th>Profession</th>
                            <th>Accepté</th>
                            <th>Actions</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $inscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($inscription->nom); ?></td>
                            <td><?php echo e($inscription->prenom); ?></td>
                            <td><?php echo e($inscription->naissance); ?></td>
                            <td><?php echo e($inscription->profession); ?></td>
                            <td>
                                <?php if($inscription->accepte==NULL ): ?>
                                <span class="badge badge-warning">En cours</span>
                                <?php elseif($inscription->accepte=='true'): ?>
                                <span class="badge badge-success">Oui</span>
                                <?php else: ?>
                                <span class="badge badge-danger">Non</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a class="btn btn-warning" data-toggle="modal" data-target="#view<?php echo e($inscription->id); ?>">
                                    Voir
                                </a>
                                <form style="display: inline-block" action="<?php echo e(url('admin/inscription/'.$inscription->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="accepte" value="true">
                                    <button type="submit" class="btn btn-success">Accepter</button>
                                </form>
                                <form style="display: inline-block" action="<?php echo e(url('admin/inscription/'.$inscription->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="accepte" value="false">
                                    <button type="submit" class="btn btn-danger">Refuser</button>
                                </form>

                            </td>

                        </tr>
                        <?php echo $__env->make('view-inscription-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<link rel="stylesheet" href="<?php echo e(asset('datatables/datatables.min.css')); ?>">

<!-- DataTables -->
<script src="<?php echo e(asset('datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('datatables/jQuery-3.7.0/jquery-3.7.0.min.js')); ?>"></script>
<script>
    let table = new DataTable('#dataTable', {
        responsive: true
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DOSSE KOVI AMEN\Desktop\Amen\visiondynamik\resources\views/inscriptions.blade.php ENDPATH**/ ?>