<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="<?php echo e(asset(Voyager::image(setting('site.icon_image')))); ?>" type="image/x-icon">

    <meta name="description" content="<?php echo e(setting('site.description')); ?>">

    <title><?php echo e(setting('site.title')); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.theme.default.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="<?php echo e(asset('css/all.min.css')); ?>">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

</head>

<body>
    <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>






    
    <?php if($errors->has('email')): ?>
    <div class="alert alert-danger">
        <?php echo e($errors->first('email')); ?>

    </div>
    <?php endif; ?>
    <section id="newsletter">

        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-6">
                    <h3 class="text-white">Inscrivez-vous à la newsletter</h3>
                    <p class="text-white">Recevez des infos nous concernant sur nos activité.</p>
                </div>
                <div class="col-12 col-lg-6">
                    <form action="<?php echo e(url('newsletters')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="d-flex flex-column flex-sm-row w-100">
                            <label for="newsletter1" class="visually-hidden">Adresse email</label>
                            <input id="newsletter1" name="email" type="email" class="newsletter-input" placeholder="Adresse email" required>
                            <button class="newsletter-btn" type="submit">S'inscrire</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>


        <!-- Ajoutez davantage de div.gallery-item pour plus de photos -->
    </section>
    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/all.min.css')); ?>"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();

    </script>
</body>

</html>
<?php /**PATH C:\Users\DOSSE KOVI AMEN\Desktop\Amen\visiondynamik\resources\views/layouts/site.blade.php ENDPATH**/ ?>