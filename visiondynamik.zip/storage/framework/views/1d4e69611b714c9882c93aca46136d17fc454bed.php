<!-- Modal -->
<div class="modal fade modal-info" id="view<?php echo e($inscription->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo e(__('voyager::generic.close')); ?>"><span aria-hidden="true">&times;</span></button>

                <h4 class="modal-title" id="exampleModalLabel"><?php echo e($activity->title); ?></h4>
            </div>
            <div class="modal-body">
                <p>Nom : <?php echo e($inscription->nom); ?></p>
                <p>Prénom : <?php echo e($inscription->prenom); ?></p>
                <p>Naissance : <?php echo e($inscription->naissance); ?></p>
                <p>Profession : <?php echo e($inscription->profession); ?></p>
                <p>Genre : <?php echo e($inscription->genre); ?></p>
                <p>Région : <?php echo e($inscription->region); ?></p>
                <p>Préfecture : <?php echo e($inscription->prefecture); ?></p>
                <p>Localité : <?php echo e($inscription->localite); ?></p>
                <p>Expérience : <?php echo e($inscription->experience); ?></p>
                <p>Motivation : <?php echo e($inscription->motivation); ?></p>
                <p>Vos attentes : <?php echo e($inscription->attentes); ?></p>
                <p>contribution : <?php echo e($inscription->contribution); ?></p>
                <p>Accepté :
                    <?php if($inscription->accepte==NULL ): ?>
                    <span class="badge badge-warning">En cours</span>
                    <?php elseif($inscription->accepte=='true'): ?>
                    <span class="badge badge-success">Oui</span>
                    <?php else: ?>
                    <span class="badge badge-danger">Non</span>
                    <?php endif; ?>
                </p>


            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\DOSSE KOVI AMEN\Desktop\Amen\visiondynamik\resources\views/view-inscription-modal.blade.php ENDPATH**/ ?>