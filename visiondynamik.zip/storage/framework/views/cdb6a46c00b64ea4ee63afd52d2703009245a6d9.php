<?php $__env->startSection('content'); ?>
<style>
    #article p::first-letter{
  font-size: 200%;
  color: #8A2BE2;
}
</style>
<section class="bg-light" id="article">
<div class="container">
    <div class="row">
        <div class="col-md-8">
            <h2 class="my-3"><?php echo e($article->title); ?> (<?php echo e('le'. $article->updated_at->format('d/m/Y')); ?>)</h2>

            <img style="object-fit: cover; height:400px; width:100%;"
            src="<?php echo e(asset(Voyager::image($article->image))); ?>" class="img-fluid"
            alt="<?php echo e($article->title); ?>" />

            <div class="text-justify p-5 bg-white">
                <p class="paragraph">
                    <?php echo $article->body; ?>

                </p>
            </div>
        </div>
        <div class="col-md-4 p-4 mt-5">
            <h3>Dernier posts</h3>
            <?php $__currentLoopData = $last_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(url('blog/article/' . $post->category?->slug . '/' . $post->slug)); ?>"><?php echo e($post->title); ?></a>
            <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DOSSE KOVI AMEN\Desktop\Amen\visiondynamik\resources\views/article.blade.php ENDPATH**/ ?>